#include<stdio.h>
int main()
{
	printf("黄维维\n");
	printf("黄\n维维\n");
	printf("黄");
	printf("维维\n");
	return 0;
}